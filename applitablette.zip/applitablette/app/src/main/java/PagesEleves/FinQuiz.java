package PagesEleves;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.R;

public class FinQuiz extends AppCompatActivity {

    private Button viewstat, backmenu;
    private TextView scoreIs, comment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fin_quiz);

        viewstat = findViewById(R.id.viewstat);
        backmenu = findViewById(R.id.backmenu);
        comment = findViewById(R.id.commentary);
        scoreIs = findViewById(R.id.scoreIs);

        Intent intent = getIntent();
        final String nom = intent.getStringExtra("nom");
        final String email = intent.getStringExtra("email");
        final String prenom = intent.getStringExtra("prenom");
        final String id = intent.getStringExtra("id");
        final String score = intent.getStringExtra("score");
        final String cpt = intent.getStringExtra("cpt");

        int pts = Integer.parseInt(score);
        int total = Integer.parseInt(cpt);
        float ratio = pts / total;
        String rate = Integer.toString((int) ratio);
        Toast.makeText(this, rate, Toast.LENGTH_SHORT).show();
        if (ratio == 1) {
            comment.setText("Perfect !");
        } else if (ratio == 0) {
            comment.setText("You know nothing !");
        } else if (ratio >= 0.75 && ratio < 1) {
            comment.setText("Very good");
        } else if (ratio >= 0.5 && ratio < 0.75) {
            comment.setText("You know some stuff about the suject");
        } else if (ratio >= 0.25 && ratio < 0.5) {
            comment.setText("You have some difficulties");
        } else if (ratio >= 0.01 && ratio < 0.25) {
            comment.setText("Your don't know your lesson");
        }

        scoreIs.setText(score + "/" + cpt);

        backmenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent act = new Intent(getApplicationContext(), Menu_eleve.class);
                act.putExtra("nom", nom);
                act.putExtra("prenom", prenom);
                act.putExtra("email", email);
                act.putExtra("id", id);
                startActivity(act);
            }
        });

        viewstat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

    }

    public void onBackPressed(){

    }

}
