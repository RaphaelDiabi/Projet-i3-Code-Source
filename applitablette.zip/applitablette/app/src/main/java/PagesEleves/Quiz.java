package PagesEleves;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapplication.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import PagesProf.CreateQuiz;
import PagesProf.Menu_Prof;
import PagesProf.MyQuiz;

public class Quiz extends AppCompatActivity {

    private TextView nomQuiz;
    private ConstraintLayout layout;
    private LinearLayout stripes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        nomQuiz = findViewById(R.id.nomQuiz);

        Intent intent = getIntent();
        final String extraName=intent.getStringExtra("nom");
        final String extraFirstName=intent.getStringExtra("prenom");
        final String extraEmail=intent.getStringExtra("email");
        final String extraId=intent.getStringExtra("id");
        final String extraNomQuiz = intent.getStringExtra("nomQuiz");
        final String extraidQuiz = intent.getStringExtra("idQuiz");

        layout = findViewById(R.id.layout);
        stripes= findViewById(R.id.stripes);

        AnimationDrawable animationDrawable = (AnimationDrawable) layout.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(4000);
        animationDrawable.start();

        Animation anim = AnimationUtils.loadAnimation(this,R.anim.stripe_anim);
        stripes.startAnimation(anim);
        
        checkStatut(extraEmail,extraFirstName,extraId,extraidQuiz,extraName,extraNomQuiz);

        nomQuiz.setText(extraNomQuiz);

    }

    private void checkStatut(final String extraEmail, final String extraFirstName, final String extraId, final String extraidQuiz, final String extraName, final String extraNomQuiz) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://192.168.1.35/waitingRoom.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try{
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if(success.equals("1")){
                        for(int i=0;i<jsonArray.length();i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            String statut = object.getString("statut").trim();

                            if(statut.equals("off")){
                                checkStatut(extraEmail,extraFirstName,extraId,extraidQuiz,extraName,extraNomQuiz);
                            }
                            else{
                                Intent act = new Intent(getApplicationContext(), AffichageQuiz.class);
                                act.putExtra("nom", extraName);
                                act.putExtra("prenom", extraFirstName);
                                act.putExtra("email", extraEmail);
                                act.putExtra("id", extraId);
                                act.putExtra("idQuiz", extraidQuiz);
                                startActivity(act);

                            }

                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(Quiz.this,"Error "+e.toString(),Toast.LENGTH_SHORT).show();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(Quiz.this,"Error "+error.toString(),Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idQuiz",extraidQuiz);
                for(int j=0;j<1000000000;j++);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

}
