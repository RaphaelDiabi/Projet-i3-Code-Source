package com.example.appli_projet;

import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.AnimationDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.example.myapplication.R;
import java.util.Locale;

public class LanguageSelect extends AppCompatActivity {

    private ImageView france;
    private ImageView anglais;
    private ImageView espagnol;

    private ConstraintLayout layout;
    private LinearLayout stripes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language_select);

        this.anglais=(ImageView) findViewById(R.id.anglais);
        this.espagnol=(ImageView) findViewById(R.id.espagnol);
        this.france=(ImageView) findViewById(R.id.français);

        layout = findViewById(R.id.layout);
        stripes= findViewById(R.id.stripes);

        AnimationDrawable animationDrawable = (AnimationDrawable) layout.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(4000);
        animationDrawable.start();

        Animation anim = AnimationUtils.loadAnimation(this,R.anim.stripe_anim);
        stripes.startAnimation(anim);


        anglais.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent select_langue = new Intent(getApplicationContext(), FirstPage.class);
                setAppLocale("en");
                startActivity(select_langue);
                finish();
            }
        });

        france.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent select_langue = new Intent(getApplicationContext(), FirstPage.class);
                setAppLocale("fr");
                startActivity(select_langue);
                finish();
            }
        });

        espagnol.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent select_langue = new Intent(getApplicationContext(), FirstPage.class);
                setAppLocale("es");
                startActivity(select_langue);
                finish();
            }
        });
    }

    private void setAppLocale(String localeCode){
        Resources res = getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            conf.setLocale(new Locale(localeCode.toLowerCase()));
        }
        else{
            conf.locale = new Locale(localeCode.toLowerCase());
        }
        res.updateConfiguration(conf,dm);
    }

    public void onBackPressed(){
        Intent act= new Intent(getApplicationContext(),FirstPage.class);
        startActivity(act);
    }

}
