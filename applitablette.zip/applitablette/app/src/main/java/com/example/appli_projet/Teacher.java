package com.example.appli_projet;

public class Teacher {

    private int idp;
    private String nomp;
    private String prenomp;
    private String emailp;
    private String passwordp;

    public Teacher(int id, String nom,String prenom,String email, String password){
        this.idp=id;
        this.nomp=nom;
        this.prenomp=prenom;
        this.emailp=email;
        this.passwordp=password;
    }

    public int getIdp(){ return idp; }

    public void setIdp(int id){
        this.idp=id;
    }

    public String getNomp(){ return nomp; }

    public void setNomp(String nom){
        this.nomp=nom;
    }

    public String getPrenomp(){ return prenomp; }

    public void setPrenomp(String prenom){
        this.prenomp=prenom;
    }

    public String getEmailp(){ return emailp; }

    public void setEmailp(String email){
        this.emailp=email;
    }

    public String getPasswordp(){ return passwordp; }

    public void setPasswordp(String password){
        this.passwordp=password;
    }


}
