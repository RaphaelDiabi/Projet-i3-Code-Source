package PagesProf;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapplication.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.HashMap;
import java.util.Map;

import PagesEleves.Menu_eleve;
import PagesEleves.Quiz;

public class EditQuiz extends AppCompatActivity {

    private Button DeleteButton,LaunchButton;
    private TextView nameQuiz;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_quiz);

        LaunchButton = findViewById(R.id.LaunchButton);
        DeleteButton = findViewById(R.id.DeleteButton);
        nameQuiz = findViewById(R.id.nameQuiz);


        Intent intent = getIntent();
        final String idQuiz=intent.getStringExtra("idQuiz");
        final String extraName = intent.getStringExtra("nom");
        final String extraFirstName = intent.getStringExtra("prenom");
        final String extraEmail = intent.getStringExtra("email");
        final String extraId = intent.getStringExtra("id");

        nameQuiz.setText(idQuiz);


        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.navBar);
        bottomNavigationView.setSelectedItemId(R.id.myQuiz);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.home:
                        Intent act = new Intent(getApplicationContext(), Menu_Prof.class);
                        act.putExtra("nom", extraName);
                        act.putExtra("email", extraEmail);
                        act.putExtra("prenom", extraFirstName);
                        act.putExtra("id", extraId);
                        startActivity(act);
                        finish();
                        overridePendingTransition(0, 0);
                        break;
                    case R.id.myQuiz:
                        Intent act3 = new Intent(getApplicationContext(), MyQuiz.class);
                        act3.putExtra("nom", extraName);
                        act3.putExtra("email", extraEmail);
                        act3.putExtra("prenom", extraFirstName);
                        act3.putExtra("id", extraId);
                        startActivity(act3);
                        finish();
                        overridePendingTransition(0, 0);
                        break;
                    case R.id.myProfile:
                        Intent act2 = new Intent(getApplicationContext(), ProfileProf.class);
                        act2.putExtra("nom", extraName);
                        act2.putExtra("email", extraEmail);
                        act2.putExtra("prenom", extraFirstName);
                        act2.putExtra("id", extraId);
                        startActivity(act2);
                        finish();
                        overridePendingTransition(0, 0);
                        break;
                }
                return false;
            }

        });


        DeleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(EditQuiz.this);
                alertDialogBuilder.setTitle("Delete quiz");
                alertDialogBuilder.setIcon(R.mipmap.redcross);
                alertDialogBuilder.setMessage("Do you want to delete the quiz ?");
                alertDialogBuilder.setCancelable(false);
                alertDialogBuilder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteQuiz(idQuiz,extraName,extraFirstName,extraEmail,extraId);
                    }
                });
                alertDialogBuilder.setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();


            }
        });

        LaunchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(EditQuiz.this);
                alertDialogBuilder.setTitle("Launch quiz");
                alertDialogBuilder.setIcon(R.mipmap.launch);
                alertDialogBuilder.setMessage("Do you want to launch the quiz ?");
                alertDialogBuilder.setCancelable(false);
                alertDialogBuilder.setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        launchQuiz(idQuiz,extraName,extraFirstName,extraEmail,extraId);
                        Intent act = new Intent(getApplicationContext(), ViewQuiz.class);
                        act.putExtra("nom", extraName);
                        act.putExtra("email", extraEmail);
                        act.putExtra("prenom", extraFirstName);
                        act.putExtra("id", extraId);
                        act.putExtra("idQuiz", idQuiz);
                        startActivity(act);
                        finish();

                    }
                });
                alertDialogBuilder.setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
            }
        });

    }

    private void launchQuiz(final String idQuiz , final String extraName, final String extraFirstName, final String extraEmail, final String extraId) {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://192.168.1.35/launchQuiz.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(EditQuiz.this,"Error "+error.toString(),Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idQuiz",idQuiz);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    private void deleteQuiz(final String idQuiz, final String extraName, final String extraFirstName, final String extraEmail, final String extraId) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://192.168.1.35/deleteQuiz.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Intent act3 = new Intent(getApplicationContext(), MyQuiz.class);
                act3.putExtra("nom", extraName);
                act3.putExtra("email", extraEmail);
                act3.putExtra("prenom", extraFirstName);
                act3.putExtra("id", extraId);
                startActivity(act3);
                finish();

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(EditQuiz.this,"Error "+error.toString(),Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idQuiz",idQuiz);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    public void onBackPressed(){

    }
}
