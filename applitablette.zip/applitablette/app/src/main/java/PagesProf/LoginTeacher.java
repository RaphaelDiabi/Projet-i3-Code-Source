package PagesProf;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.appli_projet.Register;
import com.example.myapplication.R;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginTeacher extends AppCompatActivity {

    private TextView register;
    private CardView boutton;
    private ImageView home;
    private TextInputLayout til_mail,til_mdp;
    private EditText ed_email,ed_mdp;
    String url = "http://192.168.1.35/login_prof.php";

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.register=(TextView) findViewById(R.id.register);
        this.boutton=(CardView) findViewById(R.id.boutton);
        til_mail = (TextInputLayout)findViewById(R.id.til_mail);
        til_mdp = (TextInputLayout)findViewById(R.id.til_mdp);
        ed_mdp = (EditText) findViewById(R.id.ed_mdp);
        ed_email = (EditText) findViewById(R.id.ed_email);
        //home = findViewById(R.id.home);

//        home.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent act = new Intent(getApplicationContext(), FirstPage.class);
//                startActivity(act);
//                finish();
//            }
//        });


        register.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent register_act = new Intent(getApplicationContext(), Register.class);
                startActivity(register_act);
                //finish();
            }
        });

        boutton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                String email = til_mail.getEditText().getText().toString().trim();
                String password = til_mdp.getEditText().getText().toString().trim();
                int error=0;

                if(email.isEmpty()){
                    error++;
                    til_mail.setError(getString(R.string.LoginInsertEmail));
                }
                else{
                    til_mail.setErrorEnabled(false);
                }
                if(password.isEmpty()){
                    error++;
                    til_mdp.setError(getString(R.string.LoginInsertPassword));
                }
                else{
                    til_mdp.setErrorEnabled(false);
                }
                if(error == 0){
                    til_mail.setErrorEnabled(false);
                    til_mdp.setErrorEnabled(false);
                    Login(email,password);
                }
            }
        });

    }

    private void Login(final String email, final String password){

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try{
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if(success.equals("1")){
                        for(int i=0;i<jsonArray.length();i++){
                            JSONObject object = jsonArray.getJSONObject(i);

                            String nom=object.getString("nomp").trim();
                            String mail=object.getString("emailp").trim();
                            String prenom=object.getString("prenomp").trim();
                            String id=object.getString("idp").trim();

                            Toast.makeText(LoginTeacher.this, R.string.LoggedIn, Toast.LENGTH_SHORT).show();
                            ed_email.setText("");
                            ed_mdp.setText("");

                            Intent act = new Intent(getApplicationContext(), Menu_Prof.class);
                            act.putExtra("nom",nom);
                            act.putExtra("email",mail);
                            act.putExtra("prenom",prenom);
                            act.putExtra("id",id);
                            startActivity(act);
                        }

                    }
                    else{
                        til_mail.setError(getString(R.string.EmailOrPassworsIncorrect));
                        til_mdp.setError(getString(R.string.EmailOrPassworsIncorrect));
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(LoginTeacher.this,"Error "+e.toString(),Toast.LENGTH_SHORT).show();
                }



            }
        },
        new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(LoginTeacher.this,"Error "+error.toString(),Toast.LENGTH_SHORT).show();
            }
        })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("email",email);
                params.put("password",password);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

}
