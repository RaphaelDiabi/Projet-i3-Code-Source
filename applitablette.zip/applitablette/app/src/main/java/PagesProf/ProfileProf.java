package PagesProf;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.appli_projet.FirstPage;
import com.example.myapplication.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ProfileProf extends AppCompatActivity {

    private TextView nom,email;
    private Button logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_prof);

        nom = findViewById(R.id.infoname);
        email = findViewById(R.id.infoemail);
        logout = findViewById(R.id.logout);

        final Intent intent = getIntent();
        final String extraName=intent.getStringExtra("nom");
        final String extraFirstName=intent.getStringExtra("prenom");
        final String extraEmail=intent.getStringExtra("email");
        final String extraId=intent.getStringExtra("id");

        email.setText(extraEmail);

        nom.setText(extraFirstName+" "+extraName);

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent leave = new Intent(getApplicationContext(), FirstPage.class);
                startActivity(leave);
            }
        });

        BottomNavigationView bottomNavigationView = findViewById(R.id.navBar);
        bottomNavigationView.setSelectedItemId(R.id.myProfile);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.myQuiz:
                        Intent act = new Intent(getApplicationContext(), MyQuiz.class);
                        act.putExtra("nom", extraName);
                        act.putExtra("email", extraEmail);
                        act.putExtra("prenom", extraFirstName);
                        act.putExtra("id", extraId);
                        startActivity(act);
                        finish();
                        overridePendingTransition(0,0);
                        break;
                    case R.id.myProfile:
                        break;
                    case R.id.home:
                        Intent act2 = new Intent(getApplicationContext(), Menu_Prof.class);
                        act2.putExtra("nom", extraName);
                        act2.putExtra("email", extraEmail);
                        act2.putExtra("prenom", extraFirstName);
                        act2.putExtra("id", extraId);
                        startActivity(act2);
                        finish();
                        overridePendingTransition(0,0);
                        break;
                }
                return false;

            }
        });


    }

    public void onBackPressed() {

    }
}
