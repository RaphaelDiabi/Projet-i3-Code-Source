package PagesProf;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Menu_Prof extends AppCompatActivity {


    private ImageButton create;
    String url = "http://192.168.1.35/menu_prof.php";


    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu__prof);

        create = (ImageButton) findViewById(R.id.create);

        Intent intent = getIntent();
        final String extraName = intent.getStringExtra("nom");
        final String extraFirstName = intent.getStringExtra("prenom");
        final String extraEmail = intent.getStringExtra("email");
        final String extraId = intent.getStringExtra("id");


        BottomNavigationView bottomNavigationView = findViewById(R.id.navBar);
        bottomNavigationView.setSelectedItemId(R.id.home);


        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.myQuiz:
                        Intent act = new Intent(getApplicationContext(), MyQuiz.class);
                        act.putExtra("nom", extraName);
                        act.putExtra("email", extraEmail);
                        act.putExtra("prenom", extraFirstName);
                        act.putExtra("id", extraId);
                        startActivity(act);
                        finish();
                        overridePendingTransition(0,0);
                        break;
                    case R.id.home:
                        break;
                    case R.id.myProfile:
                        Intent act2 = new Intent(getApplicationContext(), ProfileProf.class);
                        act2.putExtra("nom", extraName);
                        act2.putExtra("email", extraEmail);
                        act2.putExtra("prenom", extraFirstName);
                        act2.putExtra("id", extraId);
                        startActivity(act2);
                        finish();
                        overridePendingTransition(0,0);
                        break;
                }
                return false;
            }

        });

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent act = new Intent(getApplicationContext(), CreateQuiz.class);
                act.putExtra("nom", extraName);
                act.putExtra("email", extraEmail);
                act.putExtra("prenom", extraFirstName);
                act.putExtra("id", extraId);
                startActivity(act);
                finish();
            }
        });


    }

    public void onBackPressed() {

    }


}
