package PagesProf;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapplication.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.HashMap;
import java.util.Map;

import PagesEleves.EnterCode;
import PagesEleves.Quiz;

public class MyQuiz extends AppCompatActivity {

    public LinearLayout layout;
    private TextView noQuiz;
    private ProgressBar loading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_quiz);

        Intent intent = getIntent();
        final String extraName = intent.getStringExtra("nom");
        final String extraFirstName = intent.getStringExtra("prenom");
        final String extraEmail = intent.getStringExtra("email");
        final String extraId = intent.getStringExtra("id");

        layout = findViewById(R.id.myQuizLayout);
        noQuiz = findViewById(R.id.noQuiz);
        loading = findViewById(R.id.loadingBar);

        loading.setVisibility(View.VISIBLE);


        getnbrQuiz(extraId,extraName,extraFirstName,extraEmail);

        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.navBar);
        bottomNavigationView.setSelectedItemId(R.id.myQuiz);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.home:
                        Intent act = new Intent(getApplicationContext(), Menu_Prof.class);
                        act.putExtra("nom", extraName);
                        act.putExtra("email", extraEmail);
                        act.putExtra("prenom", extraFirstName);
                        act.putExtra("id", extraId);
                        startActivity(act);
                        finish();
                        overridePendingTransition(0,0);
                        break;
                    case R.id.myQuiz:
                        break;
                    case R.id.myProfile:
                        Intent act2 = new Intent(getApplicationContext(), ProfileProf.class);
                        act2.putExtra("nom", extraName);
                        act2.putExtra("email", extraEmail);
                        act2.putExtra("prenom", extraFirstName);
                        act2.putExtra("id", extraId);
                        startActivity(act2);
                        finish();
                        overridePendingTransition(0,0);
                        break;
                }
                return false;
            }
        });
    }

    private void getnbrQuiz(final String extraId, final String extraName, final String extraFirstName, final String extraEmail) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://192.168.1.35/getidQuiz.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try{
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if(success.equals("1")){
                        for(int i=0;i<jsonArray.length();i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            String nbrQuiz = object.getString("nbr").trim();
                            String numMin = object.getString("num").trim();
                            String cpt="0";

                            if(!nbrQuiz.equals("0")){
                                listQuiz(extraId,numMin,nbrQuiz,cpt,extraEmail,extraFirstName,extraName);

                            }else{
                                loading.setVisibility(View.INVISIBLE);
                                noQuiz.setVisibility(View.VISIBLE);
                            }

                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(MyQuiz.this,"Error "+e.toString(),Toast.LENGTH_SHORT).show();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(MyQuiz.this,"Error "+error.toString(),Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idp",extraId);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    private void listQuiz(final String extraId, final String num, final String nbrQuiz, final String cpt, final String extraEmail, final String extraFirstName, final String extraName) {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://192.168.1.35/listQuiz.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try{
                    JSONObject jsonObject = new JSONObject(response);
                    String success = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    if(success.equals("1")){
                        for(int i=0;i<jsonArray.length();i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            final String nomQuiz = object.getString("nomQuiz").trim();
                            String idQuiz = object.getString("idQuiz").trim();
                            String idp = object.getString("idp").trim();
                            String num = object.getString("num").trim();
                            int nbr = Integer.parseInt(num);
                            nbr++;
                            num=Integer.toString(nbr);

                            int compteur = Integer.parseInt(cpt);
                            compteur++;
                            final String compte=Integer.toString(compteur);

                            if(compteur == 1){
                                Button button = new Button(MyQuiz.this);
                                button.setText(nomQuiz + " \n" + idQuiz);
                                button.setId(compteur);
                                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                params.gravity = Gravity.CENTER_HORIZONTAL;
                                params.setMargins(5, 100, 5, 50);
                                button.setTextColor(getResources().getColor(R.color.white));
                                button.setBackgroundColor(getResources().getColor(R.color.add));
                                button.setMinLines(2);
                                button.setMaxLines(2);
                                button.setTextSize(18);
                                layout.addView(button, params);


                            }
                            else if(compte.equals(nbrQuiz)){

                                Button button = new Button(MyQuiz.this);
                                button.setText(nomQuiz + " \n" + idQuiz);
                                button.setId(compteur);
                                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                params.gravity = Gravity.CENTER_HORIZONTAL;
                                params.setMargins(5, 60, 5, 200);
                                button.setTextColor(getResources().getColor(R.color.white));
                                button.setBackgroundColor(getResources().getColor(R.color.add));
                                button.setMinLines(2);
                                button.setMaxLines(2);
                                button.setTextSize(18);
                                layout.addView(button, params);
                            }
                            else{
                                Button button = new Button(MyQuiz.this);
                                button.setText(nomQuiz + " \n" + idQuiz);
                                button.setId(compteur);
                                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                                params.gravity = Gravity.CENTER_HORIZONTAL;
                                params.setMargins(5, 60, 5, 50);
                                button.setTextColor(getResources().getColor(R.color.white));
                                button.setBackgroundColor(getResources().getColor(R.color.add));
                                button.setMinLines(2);
                                button.setMaxLines(2);
                                button.setTextSize(18);
                                layout.addView(button, params);
                            }

                            final Button button1;
                            button1 = findViewById(compteur);
                            button1.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    String txt = button1.getText().toString().trim();
                                    int tailleNomQuiz = nomQuiz.length()+2;
                                    String idQuiz = txt.substring(tailleNomQuiz);
                                    Intent act = new Intent(getApplicationContext(), EditQuiz.class);
                                    act.putExtra("nom", extraName);
                                    act.putExtra("email", extraEmail);
                                    act.putExtra("prenom", extraFirstName);
                                    act.putExtra("id", extraId);
                                    act.putExtra("idQuiz", idQuiz);
                                    startActivity(act);
                                    finish();

                                }
                            });

                            if(compte.equals(nbrQuiz)){
                                loading.setVisibility(View.INVISIBLE);
                            }else{
                                listQuiz(idp, num,nbrQuiz,compte,extraEmail,extraFirstName,extraName);
                            }

                        }
                    }
                    else{
                        int nbr = Integer.parseInt(num);
                        nbr++;
                        String nmbr = Integer.toString(nbr);
                        listQuiz(extraId,nmbr,nbrQuiz,cpt,extraEmail,extraFirstName,extraName);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(MyQuiz.this,"Error "+e.toString(),Toast.LENGTH_SHORT).show();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(MyQuiz.this,"Error "+error.toString(),Toast.LENGTH_SHORT).show();
                    }
                })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<>();
                params.put("idp",extraId);
                params.put("num",num);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }


    public void onBackPressed() {

    }
}
